<div class="modal fade" style="position: fixed;top: 30% !important;" id="mediaSocialModal" tabindex="-1" role="dialog" aria-labelledby="mediaSocialModal" aria-hidden="true">
    <div class="modal-dialog modal-xs vertical-align-center" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?= __('Where do you want to share?') ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="mediaSocialModalBody" class="modal-body">
            </div>
        </div>
    </div>
</div>
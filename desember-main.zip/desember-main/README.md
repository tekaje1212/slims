## Template Desember untuk SLiMS 9.6.1
Panduan baca di 
[https://www.slimskudus.web.id/2023/12/template-desember-slims-961.html](https://www.slimskudus.web.id/2023/12/template-desember-slims-961.html)